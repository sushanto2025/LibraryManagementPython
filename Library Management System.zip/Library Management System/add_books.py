def add_books():
    import csv
    with open('all_books.csv','a', newline='') as myfile:
        myfilewriter=csv.writer(myfile)
        title = input("Enter Book Title: ")
        author = input("Enter Author Name: ")
        isbn = int(input("Enter ISBN Number: "))
        year = int(input("Enter Publishing Year Number: "))
        price = int(input("Enter Book Price: "))
        quantity = int(input("Enter Quantity Number: "))
        myfilewriter.writerow([title,author,isbn,year,price,quantity])
        print("Books Added Successully")
    myfile.close()










