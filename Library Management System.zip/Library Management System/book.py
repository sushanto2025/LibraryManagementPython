
import view_all_books
import add_books
from Change_books import change_books
from delete_books import delete_books

while True:
    print("Welcome to Library Management System")
    print("0. Exit")
    print("1. Add Books")
    print("2. View All Books")
    print("3. Edit One Record")
    print("4. Remove One Record")
    
    menu = input("Select any number: ")
    
    if menu == "0":
        print("Thanks for using Library Management System ")
        break
    elif menu == "1":
        add_books.add_books()
    elif menu == "2":
        view_all_books.view_all_books()
    elif menu == "3":
        change_books()
    elif menu=="4":
        delete_books()
    else:
        print("Choose a valid number")