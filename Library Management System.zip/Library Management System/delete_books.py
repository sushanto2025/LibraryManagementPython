def delete_books():
    Heading = ['Title', 'Author', 'ISBN', 'Year', 'Price', 'Quantity']
    import csv
    all_books = []
    with open('all_books.csv', 'r') as file:
        myfile = csv.reader(file)
        for row in myfile:
            all_books.append(row)
        edit_record = int(input("\nEnter the Record You Want to Delete =>Serial No. (1-" + str(len(all_books)) + ") : "))
        print("\nHere is the Record Going to be Deleted bellow:".title())
        print("**********************************************")
        print(f"Book Information => {Heading[0]} : {all_books[edit_record-1][0]},{Heading[1]} :{all_books[edit_record-1][1]} and {Heading[2]} :{all_books[edit_record-1][2]}")
        print("***********************************************")
        yn = input("Are you sure (Y/N : ".lower())
        if yn=="y":
            x=all_books.pop(edit_record - 1)
            with open("all_books.csv", "w+", newline='') as myfile:
                change_file = csv.writer(myfile)
                for i in range(len(all_books)):
                    change_file.writerow(all_books[i])
                myfile.close()
            print(x, ".... is deleted")
        elif yn=="n":
            print("Ok, No problem")
        else:
            print("Wrong input, Try Again (Y/N")
'''       if yn == ("y"):
            print(edit_record)
            all_books.pop(edit_record-1)
            print(all_books)
            with open("all_books.csv", "w+",newline='') as myfile:
                change_file = csv.writer(myfile)
                for i in range(len(all_books)):
                    change_file.writerow(all_books[i])
                    myfile.close()
        elif yn == "n":
            
        else:
        

'''