def view_all_books():
    import csv
    all_books = []
    space = " "
    print(f"Seriol No{space:<2}Title{space:<18}Author{space:<18}ISBN{space:<5}Year{space:<3}Price{space:<3}Quantity")
    print("===========================================================================================")
    with open('all_books.csv', 'r',) as file:
        myfile = csv.reader(file)
        i=1
        for row in myfile:
            print(f"{i:<11}{row[0]:<22}{row[1]:<25}{row[2]:<8}{row[3]:<8}{row[4]:<8}{row[5]}")
            i += 1
        print("--------------------------------------------------------------------------------------------")

